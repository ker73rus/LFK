﻿using System.Collections;
using UnityEngine;

namespace Assets.Scripts
{
    public interface Game
    {
        public void Start();
    }
}